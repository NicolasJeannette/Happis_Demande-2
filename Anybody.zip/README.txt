Anybody Variable Font
=====================

This download contains Anybody as both variable fonts and static fonts.

Anybody is a variable font with these axes:
  wdth
  wght

This means all the styles are contained in these files:
  Anybody-VariableFont_wdth,wght.ttf
  Anybody-Italic-VariableFont_wdth,wght.ttf

If your app fully supports variable fonts, you can now pick intermediate styles
that aren’t available as static fonts. Not all apps support variable fonts, and
in those cases you can use the static font files for Anybody:
  static/Anybody_UltraCondensed/Anybody_UltraCondensed-Thin.ttf
  static/Anybody_UltraCondensed/Anybody_UltraCondensed-ExtraLight.ttf
  static/Anybody_UltraCondensed/Anybody_UltraCondensed-Light.ttf
  static/Anybody_UltraCondensed/Anybody_UltraCondensed-Regular.ttf
  static/Anybody_UltraCondensed/Anybody_UltraCondensed-Medium.ttf
  static/Anybody_UltraCondensed/Anybody_UltraCondensed-SemiBold.ttf
  static/Anybody_UltraCondensed/Anybody_UltraCondensed-Bold.ttf
  static/Anybody_UltraCondensed/Anybody_UltraCondensed-ExtraBold.ttf
  static/Anybody_UltraCondensed/Anybody_UltraCondensed-Black.ttf
  static/Anybody_ExtraCondensed/Anybody_ExtraCondensed-Thin.ttf
  static/Anybody_ExtraCondensed/Anybody_ExtraCondensed-ExtraLight.ttf
  static/Anybody_ExtraCondensed/Anybody_ExtraCondensed-Light.ttf
  static/Anybody_ExtraCondensed/Anybody_ExtraCondensed-Regular.ttf
  static/Anybody_ExtraCondensed/Anybody_ExtraCondensed-Medium.ttf
  static/Anybody_ExtraCondensed/Anybody_ExtraCondensed-SemiBold.ttf
  static/Anybody_ExtraCondensed/Anybody_ExtraCondensed-Bold.ttf
  static/Anybody_ExtraCondensed/Anybody_ExtraCondensed-ExtraBold.ttf
  static/Anybody_ExtraCondensed/Anybody_ExtraCondensed-Black.ttf
  static/Anybody_Condensed/Anybody_Condensed-Thin.ttf
  static/Anybody_Condensed/Anybody_Condensed-ExtraLight.ttf
  static/Anybody_Condensed/Anybody_Condensed-Light.ttf
  static/Anybody_Condensed/Anybody_Condensed-Regular.ttf
  static/Anybody_Condensed/Anybody_Condensed-Medium.ttf
  static/Anybody_Condensed/Anybody_Condensed-SemiBold.ttf
  static/Anybody_Condensed/Anybody_Condensed-Bold.ttf
  static/Anybody_Condensed/Anybody_Condensed-ExtraBold.ttf
  static/Anybody_Condensed/Anybody_Condensed-Black.ttf
  static/Anybody_SemiCondensed/Anybody_SemiCondensed-Thin.ttf
  static/Anybody_SemiCondensed/Anybody_SemiCondensed-ExtraLight.ttf
  static/Anybody_SemiCondensed/Anybody_SemiCondensed-Light.ttf
  static/Anybody_SemiCondensed/Anybody_SemiCondensed-Regular.ttf
  static/Anybody_SemiCondensed/Anybody_SemiCondensed-Medium.ttf
  static/Anybody_SemiCondensed/Anybody_SemiCondensed-SemiBold.ttf
  static/Anybody_SemiCondensed/Anybody_SemiCondensed-Bold.ttf
  static/Anybody_SemiCondensed/Anybody_SemiCondensed-ExtraBold.ttf
  static/Anybody_SemiCondensed/Anybody_SemiCondensed-Black.ttf
  static/Anybody/Anybody-Thin.ttf
  static/Anybody/Anybody-ExtraLight.ttf
  static/Anybody/Anybody-Light.ttf
  static/Anybody/Anybody-Regular.ttf
  static/Anybody/Anybody-Medium.ttf
  static/Anybody/Anybody-SemiBold.ttf
  static/Anybody/Anybody-Bold.ttf
  static/Anybody/Anybody-ExtraBold.ttf
  static/Anybody/Anybody-Black.ttf
  static/Anybody_SemiExpanded/Anybody_SemiExpanded-Thin.ttf
  static/Anybody_SemiExpanded/Anybody_SemiExpanded-ExtraLight.ttf
  static/Anybody_SemiExpanded/Anybody_SemiExpanded-Light.ttf
  static/Anybody_SemiExpanded/Anybody_SemiExpanded-Regular.ttf
  static/Anybody_SemiExpanded/Anybody_SemiExpanded-Medium.ttf
  static/Anybody_SemiExpanded/Anybody_SemiExpanded-SemiBold.ttf
  static/Anybody_SemiExpanded/Anybody_SemiExpanded-Bold.ttf
  static/Anybody_SemiExpanded/Anybody_SemiExpanded-ExtraBold.ttf
  static/Anybody_SemiExpanded/Anybody_SemiExpanded-Black.ttf
  static/Anybody_Expanded/Anybody_Expanded-Thin.ttf
  static/Anybody_Expanded/Anybody_Expanded-ExtraLight.ttf
  static/Anybody_Expanded/Anybody_Expanded-Light.ttf
  static/Anybody_Expanded/Anybody_Expanded-Regular.ttf
  static/Anybody_Expanded/Anybody_Expanded-Medium.ttf
  static/Anybody_Expanded/Anybody_Expanded-SemiBold.ttf
  static/Anybody_Expanded/Anybody_Expanded-Bold.ttf
  static/Anybody_Expanded/Anybody_Expanded-ExtraBold.ttf
  static/Anybody_Expanded/Anybody_Expanded-Black.ttf
  static/Anybody_ExtraExpanded/Anybody_ExtraExpanded-Thin.ttf
  static/Anybody_ExtraExpanded/Anybody_ExtraExpanded-ExtraLight.ttf
  static/Anybody_ExtraExpanded/Anybody_ExtraExpanded-Light.ttf
  static/Anybody_ExtraExpanded/Anybody_ExtraExpanded-Regular.ttf
  static/Anybody_ExtraExpanded/Anybody_ExtraExpanded-Medium.ttf
  static/Anybody_ExtraExpanded/Anybody_ExtraExpanded-SemiBold.ttf
  static/Anybody_ExtraExpanded/Anybody_ExtraExpanded-Bold.ttf
  static/Anybody_ExtraExpanded/Anybody_ExtraExpanded-ExtraBold.ttf
  static/Anybody_ExtraExpanded/Anybody_ExtraExpanded-Black.ttf
  static/Anybody_UltraCondensed/Anybody_UltraCondensed-ThinItalic.ttf
  static/Anybody_UltraCondensed/Anybody_UltraCondensed-ExtraLightItalic.ttf
  static/Anybody_UltraCondensed/Anybody_UltraCondensed-LightItalic.ttf
  static/Anybody_UltraCondensed/Anybody_UltraCondensed-Italic.ttf
  static/Anybody_UltraCondensed/Anybody_UltraCondensed-MediumItalic.ttf
  static/Anybody_UltraCondensed/Anybody_UltraCondensed-SemiBoldItalic.ttf
  static/Anybody_UltraCondensed/Anybody_UltraCondensed-BoldItalic.ttf
  static/Anybody_UltraCondensed/Anybody_UltraCondensed-ExtraBoldItalic.ttf
  static/Anybody_UltraCondensed/Anybody_UltraCondensed-BlackItalic.ttf
  static/Anybody_ExtraCondensed/Anybody_ExtraCondensed-ThinItalic.ttf
  static/Anybody_ExtraCondensed/Anybody_ExtraCondensed-ExtraLightItalic.ttf
  static/Anybody_ExtraCondensed/Anybody_ExtraCondensed-LightItalic.ttf
  static/Anybody_ExtraCondensed/Anybody_ExtraCondensed-Italic.ttf
  static/Anybody_ExtraCondensed/Anybody_ExtraCondensed-MediumItalic.ttf
  static/Anybody_ExtraCondensed/Anybody_ExtraCondensed-SemiBoldItalic.ttf
  static/Anybody_ExtraCondensed/Anybody_ExtraCondensed-BoldItalic.ttf
  static/Anybody_ExtraCondensed/Anybody_ExtraCondensed-ExtraBoldItalic.ttf
  static/Anybody_ExtraCondensed/Anybody_ExtraCondensed-BlackItalic.ttf
  static/Anybody_Condensed/Anybody_Condensed-ThinItalic.ttf
  static/Anybody_Condensed/Anybody_Condensed-ExtraLightItalic.ttf
  static/Anybody_Condensed/Anybody_Condensed-LightItalic.ttf
  static/Anybody_Condensed/Anybody_Condensed-Italic.ttf
  static/Anybody_Condensed/Anybody_Condensed-MediumItalic.ttf
  static/Anybody_Condensed/Anybody_Condensed-SemiBoldItalic.ttf
  static/Anybody_Condensed/Anybody_Condensed-BoldItalic.ttf
  static/Anybody_Condensed/Anybody_Condensed-ExtraBoldItalic.ttf
  static/Anybody_Condensed/Anybody_Condensed-BlackItalic.ttf
  static/Anybody_SemiCondensed/Anybody_SemiCondensed-ThinItalic.ttf
  static/Anybody_SemiCondensed/Anybody_SemiCondensed-ExtraLightItalic.ttf
  static/Anybody_SemiCondensed/Anybody_SemiCondensed-LightItalic.ttf
  static/Anybody_SemiCondensed/Anybody_SemiCondensed-Italic.ttf
  static/Anybody_SemiCondensed/Anybody_SemiCondensed-MediumItalic.ttf
  static/Anybody_SemiCondensed/Anybody_SemiCondensed-SemiBoldItalic.ttf
  static/Anybody_SemiCondensed/Anybody_SemiCondensed-BoldItalic.ttf
  static/Anybody_SemiCondensed/Anybody_SemiCondensed-ExtraBoldItalic.ttf
  static/Anybody_SemiCondensed/Anybody_SemiCondensed-BlackItalic.ttf
  static/Anybody/Anybody-ThinItalic.ttf
  static/Anybody/Anybody-ExtraLightItalic.ttf
  static/Anybody/Anybody-LightItalic.ttf
  static/Anybody/Anybody-Italic.ttf
  static/Anybody/Anybody-MediumItalic.ttf
  static/Anybody/Anybody-SemiBoldItalic.ttf
  static/Anybody/Anybody-BoldItalic.ttf
  static/Anybody/Anybody-ExtraBoldItalic.ttf
  static/Anybody/Anybody-BlackItalic.ttf
  static/Anybody_SemiExpanded/Anybody_SemiExpanded-ThinItalic.ttf
  static/Anybody_SemiExpanded/Anybody_SemiExpanded-ExtraLightItalic.ttf
  static/Anybody_SemiExpanded/Anybody_SemiExpanded-LightItalic.ttf
  static/Anybody_SemiExpanded/Anybody_SemiExpanded-Italic.ttf
  static/Anybody_SemiExpanded/Anybody_SemiExpanded-MediumItalic.ttf
  static/Anybody_SemiExpanded/Anybody_SemiExpanded-SemiBoldItalic.ttf
  static/Anybody_SemiExpanded/Anybody_SemiExpanded-BoldItalic.ttf
  static/Anybody_SemiExpanded/Anybody_SemiExpanded-ExtraBoldItalic.ttf
  static/Anybody_SemiExpanded/Anybody_SemiExpanded-BlackItalic.ttf
  static/Anybody_Expanded/Anybody_Expanded-ThinItalic.ttf
  static/Anybody_Expanded/Anybody_Expanded-ExtraLightItalic.ttf
  static/Anybody_Expanded/Anybody_Expanded-LightItalic.ttf
  static/Anybody_Expanded/Anybody_Expanded-Italic.ttf
  static/Anybody_Expanded/Anybody_Expanded-MediumItalic.ttf
  static/Anybody_Expanded/Anybody_Expanded-SemiBoldItalic.ttf
  static/Anybody_Expanded/Anybody_Expanded-BoldItalic.ttf
  static/Anybody_Expanded/Anybody_Expanded-ExtraBoldItalic.ttf
  static/Anybody_Expanded/Anybody_Expanded-BlackItalic.ttf
  static/Anybody_ExtraExpanded/Anybody_ExtraExpanded-ThinItalic.ttf
  static/Anybody_ExtraExpanded/Anybody_ExtraExpanded-ExtraLightItalic.ttf
  static/Anybody_ExtraExpanded/Anybody_ExtraExpanded-LightItalic.ttf
  static/Anybody_ExtraExpanded/Anybody_ExtraExpanded-Italic.ttf
  static/Anybody_ExtraExpanded/Anybody_ExtraExpanded-MediumItalic.ttf
  static/Anybody_ExtraExpanded/Anybody_ExtraExpanded-SemiBoldItalic.ttf
  static/Anybody_ExtraExpanded/Anybody_ExtraExpanded-BoldItalic.ttf
  static/Anybody_ExtraExpanded/Anybody_ExtraExpanded-ExtraBoldItalic.ttf
  static/Anybody_ExtraExpanded/Anybody_ExtraExpanded-BlackItalic.ttf

Get started
-----------

1. Install the font files you want to use

2. Use your app's font picker to view the font family and all the
available styles

Learn more about variable fonts
-------------------------------

  https://developers.google.com/web/fundamentals/design-and-ux/typography/variable-fonts
  https://variablefonts.typenetwork.com
  https://medium.com/variable-fonts

In desktop apps

  https://theblog.adobe.com/can-variable-fonts-illustrator-cc
  https://helpx.adobe.com/nz/photoshop/using/fonts.html#variable_fonts

Online

  https://developers.google.com/fonts/docs/getting_started
  https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Fonts/Variable_Fonts_Guide
  https://developer.microsoft.com/en-us/microsoft-edge/testdrive/demos/variable-fonts

Installing fonts

  MacOS: https://support.apple.com/en-us/HT201749
  Linux: https://www.google.com/search?q=how+to+install+a+font+on+gnu%2Blinux
  Windows: https://support.microsoft.com/en-us/help/314960/how-to-install-or-remove-a-font-in-windows

Android Apps

  https://developers.google.com/fonts/docs/android
  https://developer.android.com/guide/topics/ui/look-and-feel/downloadable-fonts

License
-------
Please read the full license text (OFL.txt) to understand the permissions,
restrictions and requirements for usage, redistribution, and modification.

You can use them in your products & projects – print or digital,
commercial or otherwise.

This isn't legal advice, please consider consulting a lawyer and see the full
license for all details.
